use actix_web::{web, App, HttpServer, middleware::Logger};
use std::io;
use crate::routes::configure_routes;
use crate::db::mongo::init;
use env_logger::Env;

mod routes;
mod db;
mod models;
mod services;

#[actix_web::main]
async fn main() -> io::Result<()> {
    env_logger::Builder::from_env(Env::default().default_filter_or("info")).init();

    let mongo_data = web::Data::new(init().await.expect("Failed to initialize MongoDB client"));

    HttpServer::new(move || {
        App::new()
            .wrap(Logger::default()) 
            .app_data(mongo_data.clone())  
            .configure(configure_routes)
    })
    .bind("127.0.0.1:8080")?
    .run()
    .await
}
