use actix_web::{web, HttpResponse, post};
use crate::services::auth_service::{login, register};
use crate::models::users::{AuthPayload, AuthResponse};

#[post("/login")]
async fn login_route(form: web::Json<AuthPayload>) -> HttpResponse {
    match login(form.into_inner()).await {
        Ok(user) => HttpResponse::Ok().json(user),
        Err(err) => HttpResponse::BadRequest().body(err),
    }
}

#[post("/register")]
async fn register_route(form: web::Json<AuthPayload>) -> HttpResponse {
    match register(form.into_inner()).await {
        Ok(user) => HttpResponse::Ok().json(user),
        Err(err) => HttpResponse::BadRequest().body(err),
    }
}

pub fn configure_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(login_route);
    cfg.service(register_route);
}
