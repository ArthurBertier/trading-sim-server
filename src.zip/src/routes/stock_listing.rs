use actix_web::{post, web, HttpResponse};
use mongodb::Client;
use crate::services::stock_service::stockList;
use crate::models::stock_models::StockListingPayload;

// #[post("/performingStocks")]
// async fn performinStock_route(form: web::Json<StockListingPayload>) -> HttpResponse {
//     match performingStocks(form.into_inner()).await {
//         Ok(user) => HttpResponse::Ok().json(user),
//         Err(err) => HttpResponse::BadRequest().body(err),
//     }
// }

#[post("/stock-list")]
async fn stock_list_route(data: web::Data<Client>, form: web::Json<StockListingPayload>) -> HttpResponse {
    match stockList(form.into_inner(), data).await {
        Ok(user) => HttpResponse::Ok().json(user),
        Err(err) => HttpResponse::BadRequest().body(err.to_string()),
    }
}


pub fn configure_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(stock_list_route);
    //cfg.service(performinStock_route);
}
