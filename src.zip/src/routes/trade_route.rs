use actix_web::{post, web, HttpResponse, Responder};
use crate::trade_services::{create_trade, update_user_balance_and_trades};
use crate::trade_models::{TradeData};

#[post("/trade_submit")]
async fn submit_trade(trade_data: web::Json<TradeData>) -> impl Responder {
    let trade_data = trade_data.into_inner();

    match create_trade(&trade_data).await {
        Ok(trade_id) => {
            if let Err(e) = update_user_balance_and_trades(&trade_data.user_id, &trade_id, trade_data.amount).await {
                return HttpResponse::InternalServerError().json(format!("Failed to update user: {}", e));
            }
            HttpResponse::Ok().json(trade_id.to_hex())
        }
        Err(e) => HttpResponse::InternalServerError().json(format!("Failed to create trade: {}", e)),
    }
}

pub fn init_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(submit_trade);
}
