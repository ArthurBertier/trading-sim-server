use log::{info, warn, error};
use mongodb::{bson::doc, Collection, Database, Client};
use bcrypt::{hash, verify, DEFAULT_COST};
use crate::models::users::{User, AuthPayload, AuthResponse};
use crate::db::mongo;
use crate::models::users::{UserNotifications, UserProfile, UserSettings};


pub async fn get_database() -> Result<Database, String> {
    let client: Client = mongo::init().await.map_err(|e| e.to_string())?;
    Ok(client.database("trading_simulator"))
}


pub async fn login(payload: AuthPayload) -> Result<AuthResponse, String> {
    let db = get_database().await?;
    let users: Collection<User> = db.collection("users");

    match users.find_one(doc! {"email": &payload.email}, None).await {
        Ok(Some(user)) => {
            if verify(&payload.password, &user.password).is_ok() {
                info!("Login successful for: {}", payload.email);
                Ok(AuthResponse {
                    success: true,
                    message: "Login successful".to_string(),
                    user_id: user.id.map(|id| id.to_hex())
                })
            } else {
                warn!("Failed login attempt for: {}", payload.email);
                Err("Invalid email or password".into())
            }
        },
        Ok(None) => {
            warn!("No user found for email: {}", payload.email);
            Err("User not found".into())
        },
        Err(e) => {
            error!("Database error during login: {}", e);
            Err("Internal server error".into())
        }
    }
}

pub async fn register(payload: AuthPayload) -> Result<AuthResponse, String> {
    let db = get_database().await?;
    let users: Collection<User> = db.collection("users");

    if users.find_one(doc! {"email": &payload.email}, None).await.unwrap().is_some() {
        warn!("Registration attempt for already registered email: {}", payload.email);
        return Err("Email already registered".into());
    }

    let hashed_password = hash(&payload.password, DEFAULT_COST).unwrap_or_else(|_| {
        error!("Password hashing failed for: {}", payload.email);
        panic!("Password hashing failed")
    });

    let new_user = User {
        id: None,
        email: payload.email.clone(),
        password: hashed_password,
        name: None,
        profile: UserProfile { bio: None, avatar_url: None },
        settings: UserSettings { theme: "light".to_string(), notifications: UserNotifications { email: true, sms: false } },
    };

    match users.insert_one(new_user, None).await {
        Ok(_) => {
            info!("User registration successful for: {}", payload.email);
            Ok(AuthResponse {
                success: true,
                message: "Registration successful".to_string(),
                user_id: None
            })
        },
        Err(e) => {
            error!("Failed to register user: {}", e);
            Err("Internal server error".into())
        }
    }
}
