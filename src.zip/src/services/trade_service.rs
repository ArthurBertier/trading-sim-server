use mongodb::{bson::{doc, oid::ObjectId}, Client, Collection};
use crate::trade_models::{TradeData, Trade, TradeStatus};
use crate::user_models::User;
use std::env;

pub async fn create_trade(trade_data: &TradeData) -> Result<ObjectId, Box<dyn std::error::Error>> {
    let client = Client::with_uri_str(&env::var("MONGO_URI")?).await?;
    let db = client.database(&env::var("DB_NAME")?);
    let collection: Collection<Trade> = db.collection("trades");

    let user_id = ObjectId::with_string(&trade_data.user_id)?;
    
    let new_trade = Trade {
        id: None,
        ticker: trade_data.ticker.clone(),
        position: trade_data.position.clone(),
        quantity: trade_data.quantity,
        price: trade_data.price,
        take_profit: trade_data.take_profit,
        stop_loss: trade_data.stop_loss,
        status: TradeStatus::InProgress,
        user_id,
        amount: trade_data.amount,
    };

    let insert_result = collection.insert_one(new_trade, None).await?;
    Ok(insert_result.inserted_id.as_object_id().unwrap())
}

pub async fn update_user_balance_and_trades(user_id: &str, trade_id: &ObjectId, amount: f64) -> Result<(), Box<dyn std::error::Error>> {
    let client = Client::with_uri_str(&env::var("MONGO_URI")?).await?;
    let db = client.database(&env::var("DB_NAME")?);
    let users_collection: Collection<User> = db.collection("users");

    let user_id = ObjectId::with_string(user_id)?;

    let filter = doc! { "_id": user_id };
    let update = doc! {
        "$addToSet": { "trades": trade_id },
        "$inc": { "balance": -amount },
    };

    users_collection.update_one(filter, update, None).await?;
    Ok(())
}
